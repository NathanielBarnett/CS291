// Nathaniel A. Barnett
// 2/22/2016
// Lab #5

#include "LibraryBook.h"
#include <string>
using namespace std;

// Constructors

LibraryBook::LibraryBook()
{
	string title = "", author = "", ISBN = "";
	bool checkedOut = false;
}

LibraryBook::LibraryBook(string T, string A, string bookNum)
{
	title = T;
	author = A;
	ISBN = bookNum;
	bool checkedOut = false;
}

// Setters
void LibraryBook::checkOut()
{
	checkedOut = true;
}

void LibraryBook::checkIn()
{
	checkedOut = false;
}

