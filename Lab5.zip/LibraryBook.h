// Nathaniel A. Barnett
// 2/22/2016
// Lab #5

// Ensure class isn't added more than once
#ifndef LIBRARYBOOK_H
#define LIBRARYBOOK_H

#include <string>
using namespace std;

// Write LibraryBook class here
class LibraryBook
{
	//private variables
private:
	string title, author, ISBN;
	bool checkedOut;
	
	// public variables
public:
	LibraryBook(); // default constructor
	LibraryBook(string T, string A, string bookNum); // sets string variables to parameters passed in, checkedOut is set to false

	// Getters ( Inlined for brevity)
	string getTitle() { return title; } 
	string getAuthor() { return author; }
	string getISBN() { return ISBN; }
	bool isCheckedOut() { return checkedOut; } // returns true if book is checked out, false if book is not checked out

	// Setters
	void checkOut(); // sets member variable of checkedOut to true
	void checkIn(); // sets member variable of checkedOut to false
};

// This matches #ifndef at beginning of the file, so leave it in
#endif