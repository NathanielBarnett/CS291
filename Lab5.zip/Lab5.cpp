// Nathaniel A. Barnett
// 2/22/2016
// Lab #5

#include "LibraryBook.h"
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main() {
	// File stream variables
    ifstream finBooks("books.txt");
	ifstream finISBN("isbns.txt");
	ofstream fout("checkedout.txt");

	// Program variables
	string tempTitle, tempAuthor, tempISBN;
	vector<LibraryBook> libBooks;


	// Check for file errors first
	if(!finBooks || !finISBN)
	{
		cout << "Error opening input files!\n";
		system("pause");
		return 1;
	}


    // Main Body
	while (finBooks.good()) // While the there are books to be read into system...
	{
		getline(finBooks, tempTitle); getline(finBooks, tempAuthor); getline(finBooks, tempISBN); // Get line for title, get line for author, get line for ISBN
		LibraryBook CSBook(tempTitle, tempAuthor, tempISBN); // Create object of type LibraryBook with the temporary title, author, and ISBN
		libBooks.push_back(CSBook); // Add to back of vector
	}
	
	while (finISBN.good()) 
	{
		finISBN >> tempISBN;  // read in ISBN from file
		for (int i = 0; i < libBooks.size(); i++)  // 
		{
			if (libBooks[i].getISBN() == tempISBN)
			{
				if (libBooks[i].isCheckedOut())
				{
					libBooks[i].checkIn();
				}
				else
				{
					libBooks[i].checkOut();
				}
				break;
			}
		}
	}

	fout << "Books checked out:" << endl << "------------------" << endl << endl;
	fout << "Title\t" << "Author\t" << "ISBN\t" << endl;
	for (int i = 0; i < libBooks.size(); i++)
	{
		if (!libBooks[i].isCheckedOut())
		{
			fout << libBooks[i].getTitle() << "\t" << libBooks[i].getAuthor() << "\t"
				<< libBooks[i].getISBN() << "\t" << endl;
		}
	}
	

	// Close the files at the end
	finBooks.close();
	finISBN.close();
	fout.close();

    // End program
	return 0;
}
